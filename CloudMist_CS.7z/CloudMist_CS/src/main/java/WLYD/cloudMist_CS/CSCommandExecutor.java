package WLYD.cloudMist_CS;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import WLYD.cloudMist_CS.game.CSGame;
import WLYD.cloudMist_CS.game.Team;
import WLYD.cloudMist_CS.weapon.WeaponType;
import WLYD.cloudMist_CS.game.GameState;
import WLYD.cloudMist_CS.game.GameSettings;
import WLYD.cloudMist_CS.game.GamePreset;

public class CSCommandExecutor implements CommandExecutor {
    private final CloudMist_CS plugin;
    
    public CSCommandExecutor(CloudMist_CS plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            showHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload":
                if (!sender.hasPermission("cloudmist.cs.admin")) {
                    sender.sendMessage("§c你没有权限执行此命令!");
                    return true;
                }
                handleReload(sender);
                return true;
            case "create":
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§c此命令只能由玩家执行!");
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /cmcs create <名称>");
                    return true;
                }
                handleCreate((Player)sender, args[1]);
                break;
                
            case "join":
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /cmcs join <名称>");
                    return true;
                }
                handleJoin(sender, args[1]);
                break;
                
            case "leave":
                handleLeave(sender);
                break;
                
            case "team":
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /cmcs team <t|ct>");
                    return true;
                }
                handleTeam(sender, args[1]);
                break;
                
            case "start":
                handleStart(sender);
                break;
                
            case "setspawn":
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /cmcs setspawn <t|ct>");
                    return true;
                }
                handleSetSpawn(sender, args[1]);
                break;
                
            case "buy":
                if (args.length < 2) {
                    showBuyMenu(sender);
                    return true;
                }
                handleBuy(sender, args[1]);
                break;
                
            case "settings":
                if (args.length < 3) {
                    showSettingsHelp(sender);
                    return true;
                }
                handleSettings(sender, args[1], args[2]);
                break;
                
            case "savesettings":
                handleSaveSettings(sender);
                break;
                
            case "loadsettings":
                handleLoadSettings(sender);
                break;
                
            case "showsettings":
                handleShowSettings(sender);
                break;
                
            case "preset":
                if (args.length < 2) {
                    showPresetHelp(sender);
                    return true;
                }
                handlePreset(sender, args[1]);
                break;
                
            case "setbombsite":
                if (args.length < 3) {
                    sender.sendMessage("§c用法: /cmcs setbombsite <名称> <半径>");
                    return true;
                }
                handleSetBombSite(sender, args[1], Double.parseDouble(args[2]));
                return true;
                
            default:
                showHelp(sender);
                break;
        }
        
        return true;
    }
    
    private void showHelp(CommandSender sender) {
        sender.sendMessage("§6=== CloudMist CS 帮助 ===");
        if (sender.hasPermission("cloudmist.cs.admin")) {
            sender.sendMessage("§f/cmcs reload - 重加载插件配置");
        }
        if (sender instanceof Player) {
            sender.sendMessage("§f/cmcs create <名称> - 创建新的游戏场景");
            sender.sendMessage("§f/cmcs join <名称> - 加入一个游戏");
            sender.sendMessage("§f/cmcs leave - 离开当前游戏");
            sender.sendMessage("§f/cmcs team <t|ct> - 选择队伍");
            sender.sendMessage("§f/cmcs start - 开始游戏");
            sender.sendMessage("§f/cmcs setspawn <t|ct> - 设置队伍出生点");
            sender.sendMessage("§f/cmcs buy [武器] - 购买武器");
        }
        sender.sendMessage("§f/cmcs settings [设置项] [值] - 设置游戏设置");
        sender.sendMessage("§f/cmcs savesettings - 保存当前游戏设置");
        sender.sendMessage("§f/cmcs loadsettings - 加载保存的游戏设置");
        sender.sendMessage("§f/cmcs showsettings - 显示当前游戏设置");
        sender.sendMessage("§f/cmcs preset <模式> - 应用游戏预设");
        if (sender.hasPermission("cloudmist.cs.admin")) {
            sender.sendMessage("§f/cmcs setbombsite <名称> <半径> - 设置炸弹安装点");
        }
    }
    
    private void handleCreate(Player player, String name) {
        if (plugin.getGameManager().createGame(name, player.getLocation())) {
            player.sendMessage("§a成功创建游戏: " + name);
            player.sendMessage("§e提示: 你现在可以使用以下命令设置游戏:");
            player.sendMessage("§e- /cmcs setspawn t - 设置T队出生点");
            player.sendMessage("§e- /cmcs setspawn ct - 设置CT队出生点");
            player.sendMessage("§e- /cmcs settings - 查看可用的游戏设置");
        } else {
            player.sendMessage("§c游戏已存在: " + name);
        }
    }
    
    private void handleJoin(CommandSender sender, String name) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        if (plugin.getGameManager().joinGame(player, name)) {
            // 成功加入的消息在CSGame.addPlayer中已发送
        } else {
            sender.sendMessage("§c无法加入游戏: " + name);
        }
    }
    
    private void handleLeave(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        if (plugin.getGameManager().leaveGame(player)) {
            // 离开游戏的消息在CSGame.removePlayer中已发送
        } else {
            sender.sendMessage("§c你当前不在任何游戏中");
        }
    }
    
    private void handleTeam(CommandSender sender, String teamName) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        Team team;
        switch (teamName.toLowerCase()) {
            case "t":
                team = Team.TERRORIST;
                break;
            case "ct":
                team = Team.COUNTER_TERRORIST;
                break;
            default:
                sender.sendMessage("§c无效的队伍! 使用 t 或 ct");
                return;
        }
        
        if (game.joinTeam(player, team)) {
            // 成功加入队伍的消息已在 joinTeam 中发送
        }
    }
    
    private void handleStart(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        if (game.startGame()) {
            // 成功开始游戏的消息已在startGame中发送
        } else {
            sender.sendMessage("§c无法开始游戏，请确保双方队伍人数足够!");
        }
    }
    
    private void handleSetSpawn(CommandSender sender, String teamName) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getGameByLocation(player.getLocation());
        if (game == null) {
            sender.sendMessage("§c你必须在游戏区域内设置出生点!");
            return;
        }
        
        if (!sender.hasPermission("cloudmist.cs.admin")) {
            sender.sendMessage("§c你没有权限设置出生点!");
            return;
        }
        
        Team team;
        switch (teamName.toLowerCase()) {
            case "t":
                team = Team.TERRORIST;
                break;
            case "ct":
                team = Team.COUNTER_TERRORIST;
                break;
            default:
                sender.sendMessage("§c无效的队伍! 使用 t 或 ct");
                return;
        }
        
        game.setSpawnPoint(team, player.getLocation());
        sender.sendMessage(String.format("§a已设置 %s §a队伍的出生点", team.getDisplayName()));
    }
    
    private void showBuyMenu(CommandSender sender) {
        sender.sendMessage("§6=== 武器购买菜单 ===");
        sender.sendMessage("§f手枪:");
        sender.sendMessage("§f  /cmcs buy glock17 - 格洛克17 ($400)");
        sender.sendMessage("§f  /cmcs buy deagle - 沙漠之鹰 ($700)");
        sender.sendMessage("§f步枪:");
        sender.sendMessage("§f  /cmcs buy m4a1 - M4A1 ($3100) [CT]");
        sender.sendMessage("§f  /cmcs buy ak47 - AK47 ($2700) [T]");
        sender.sendMessage("§f  /cmcs buy awp - AWP ($4750)");
    }
    
    private void handleBuy(CommandSender sender, String weaponName) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        if (game.getState() != GameState.BUY_TIME) {
            sender.sendMessage("§c只能在购买时间内购买武器!");
            return;
        }
        
        Team team = game.getPlayerTeam(player);
        if (team != Team.TERRORIST && team != Team.COUNTER_TERRORIST) {
            sender.sendMessage("§c只有参与游戏的玩家才能购买武器!");
            return;
        }
        
        WeaponType weapon = null;
        switch (weaponName.toLowerCase()) {
            case "glock17": weapon = WeaponType.GLOCK17; break;
            case "deagle": weapon = WeaponType.DEAGLE; break;
            case "m4a1": weapon = WeaponType.M4A1; break;
            case "ak47": weapon = WeaponType.AK47; break;
            case "awp": weapon = WeaponType.AWP; break;
            default:
                sender.sendMessage("§c未知的武器! 使用 /cmcs buy 查看可用武器");
                return;
        }
        
        plugin.getWeaponManager().buyWeapon(player, weapon, team == Team.COUNTER_TERRORIST, game);
    }
    
    private void showSettingsHelp(CommandSender sender) {
        sender.sendMessage("§6=== CS游戏设置 ===");
        sender.sendMessage("§f/cmcs settings roundtime <60-300> - 设置回合时间（秒）");
        sender.sendMessage("§f/cmcs settings startmoney <0-16000> - 置初始金钱");
        sender.sendMessage("§f/cmcs settings minplayers <1-5> - 设置每队最少玩家数");
        sender.sendMessage("§f/cmcs settings maxplayers <1-10> - 设置每队最多玩家数");
        sender.sendMessage("§f/cmcs settings winscore <8-30> - 设置胜利需要的分数");
        sender.sendMessage("§f/cmcs settings killreward <0-3000> - 设置击杀奖励");
        sender.sendMessage("§f/cmcs settings winreward <1000-5000> - 设置赢回合奖励");
        sender.sendMessage("§f/cmcs settings losereward <1000-3000> - 设置输回合奖励");
        sender.sendMessage("§f/cmcs settings freezetime <0-15> - 设置冻结时间");
        sender.sendMessage("§f/cmcs settings friendlyfire <true/false> - 设置友军伤害");
    }
    
    private void handleSettings(CommandSender sender, String setting, String value) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game;
        
        // 如果玩家有管理员权限，允许通过位置获取游戏
        if (sender.hasPermission("cloudmist.cs.admin")) {
            game = plugin.getGameManager().getGameByLocation(player.getLocation());
            if (game == null) {
                // 如果通过置找不到，尝试获取玩家所在的游戏
                game = plugin.getGameManager().getPlayerGame(player);
            }
        } else {
            // 普通玩家必须加入游戏才能修改设置
            game = plugin.getGameManager().getPlayerGame(player);
        }
        
        if (game == null) {
            sender.sendMessage("§c找不到可以修改的游戏! 请确保你在游戏区域内或已加入游戏。");
            return;
        }
        
        // 检查权限
        if (!sender.hasPermission("cloudmist.cs.admin")) {
            sender.sendMessage("§c你没有权限修改游戏设置!");
            return;
        }

        GameSettings settings = game.getSettings();
        try {
            switch (setting.toLowerCase()) {
                case "roundtime":
                    settings.setRoundTime(Integer.parseInt(value));
                    break;
                case "startmoney":
                    settings.setStartMoney(Integer.parseInt(value));
                    break;
                case "minplayers":
                    settings.setMinPlayersPerTeam(Integer.parseInt(value));
                    break;
                case "maxplayers":
                    settings.setMaxPlayersPerTeam(Integer.parseInt(value));
                    break;
                case "winscore":
                    settings.setWinScore(Integer.parseInt(value));
                    break;
                case "killreward":
                    settings.setKillReward(Integer.parseInt(value));
                    break;
                case "winreward":
                    settings.setWinRoundReward(Integer.parseInt(value));
                    break;
                case "losereward":
                    settings.setLoseRoundReward(Integer.parseInt(value));
                    break;
                case "freezetime":
                    settings.setFreezeTime(Integer.parseInt(value));
                    break;
                case "friendlyfire":
                    settings.setFriendlyFire(Boolean.parseBoolean(value));
                    break;
                default:
                    sender.sendMessage("§c未知的设置项! 使用 /cmcs settings 查看可用设置");
                    return;
            }
            sender.sendMessage(String.format("§a成功设置 %s 为 %s", setting, value));
        } catch (NumberFormatException e) {
            sender.sendMessage("§c无效的数值!");
        }
    }
    
    private void handleSaveSettings(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        game.saveSettings();
        sender.sendMessage("§a游戏设置已保存!");
    }
    
    private void handleLoadSettings(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        game.loadSettings();
        sender.sendMessage("§a游戏设置已加载!");
    }
    
    private void handleShowSettings(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        GameSettings settings = game.getSettings();
        sender.sendMessage("§6=== 当前游戏设置 ===");
        sender.sendMessage(String.format("§f回合时间: §e%d秒", settings.getRoundTime()));
        sender.sendMessage(String.format("§f初始金钱: §e$%d", settings.getStartMoney()));
        sender.sendMessage(String.format("§f每队最少玩家: §e%d", settings.getMinPlayersPerTeam()));
        sender.sendMessage(String.format("§f每队最多玩家: §e%d", settings.getMaxPlayersPerTeam()));
        sender.sendMessage(String.format("§f胜利分数: §e%d", settings.getWinScore()));
        sender.sendMessage(String.format("§f击杀奖励: §e$%d", settings.getKillReward()));
        sender.sendMessage(String.format("§f胜利奖励: §e$%d", settings.getWinRoundReward()));
        sender.sendMessage(String.format("§f失败奖励: §e$%d", settings.getLoseRoundReward()));
        sender.sendMessage(String.format("§f冻结时间: §e%d秒", settings.getFreezeTime()));
        sender.sendMessage(String.format("§f友军伤害: §e%s", settings.isFriendlyFire() ? "开启" : "关"));
    }
    
    private void showPresetHelp(CommandSender sender) {
        sender.sendMessage("§6=== CS游戏预设 ===");
        for (GamePreset preset : GamePreset.values()) {
            sender.sendMessage(String.format("&f/cmcs preset %s - %s", 
                preset.name().toLowerCase(), preset.getDisplayName()));
        }
    }
    
    private void handlePreset(CommandSender sender, String presetName) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getPlayerGame(player);
        if (game == null) {
            sender.sendMessage("§c你必须先加入一个游戏!");
            return;
        }
        
        try {
            GamePreset preset = GamePreset.valueOf(presetName.toUpperCase());
            game.getSettings().applyPreset(preset);
            sender.sendMessage(String.format("§a已应用预设: %s", preset.getDisplayName()));
            handleShowSettings(sender); // 显示新的设置
        } catch (IllegalArgumentException e) {
            sender.sendMessage("§c未知的预设! 使用 /cmcs preset 查看可用预设");
        }
    }
    
    private void handleReload(CommandSender sender) {
        try {
            plugin.reloadConfig();
            plugin.getWeaponManager().reloadConfig();
            sender.sendMessage("§a插件置已重新加载!");
        } catch (Exception e) {
            sender.sendMessage("§c重载配置时发生错误，请查看控制台!");
            e.printStackTrace();
        }
    }
    
    private void handleSetBombSite(CommandSender sender, String name, double radius) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行!");
            return;
        }
        
        Player player = (Player) sender;
        CSGame game = plugin.getGameManager().getGameByLocation(player.getLocation());
        
        if (game == null) {
            sender.sendMessage("§c你必须在游戏区域内设置炸弹安装点!");
            return;
        }
        
        if (!sender.hasPermission("cloudmist.cs.admin")) {
            sender.sendMessage("§c你没有权限设置炸弹安装点!");
            return;
        }
        
        game.registerBombSite(name, player.getLocation(), radius);
        sender.sendMessage(String.format("§a已设置炸弹安装点 %s (半径: %.1f)", name, radius));
    }
} 