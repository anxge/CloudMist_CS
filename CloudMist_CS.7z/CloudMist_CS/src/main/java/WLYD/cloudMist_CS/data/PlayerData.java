package WLYD.cloudMist_CS.data;

import org.bukkit.configuration.file.YamlConfiguration;
import java.util.Map;
import java.util.HashMap;

public class PlayerData {
    private int kills;
    private int deaths;
    private int wins;
    private int losses;
    private int bombPlants;
    private int bombDefuses;
    private Map<String, String> loadouts;
    
    public PlayerData() {
        this.loadouts = new HashMap<>();
    }
    
    public static PlayerData fromConfig(YamlConfiguration config) {
        PlayerData data = new PlayerData();
        data.kills = config.getInt("stats.kills", 0);
        data.deaths = config.getInt("stats.deaths", 0);
        data.wins = config.getInt("stats.wins", 0);
        data.losses = config.getInt("stats.losses", 0);
        data.bombPlants = config.getInt("stats.bomb_plants", 0);
        data.bombDefuses = config.getInt("stats.bomb_defuses", 0);
        @SuppressWarnings("unchecked")
        Map<String, String> loadouts = (Map<String, String>) config.get("loadouts");
        data.loadouts = loadouts != null ? loadouts : new HashMap<>();
        return data;
    }
    
    // Getters
    public int getKills() { return kills; }
    public int getDeaths() { return deaths; }
    public int getWins() { return wins; }
    public int getLosses() { return losses; }
    public int getBombPlants() { return bombPlants; }
    public int getBombDefuses() { return bombDefuses; }
    public Map<String, String> getLoadouts() { return loadouts; }
}