package WLYD.cloudMist_CS.weapon;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import WLYD.cloudMist_CS.CloudMist_CS;
import WLYD.cloudMist_CS.game.CSGame;
import WLYD.cloudMist_CS.game.Team;
import org.bukkit.configuration.ConfigurationSection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.EnumMap;
import java.util.logging.Logger;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;

public class WeaponManager {
    private static final Logger LOGGER = Logger.getLogger(WeaponManager.class.getName());
    private static final String TACZ_MOD_ID = "tacz";
    private static final String TACZ_REGISTRY_CLASS = "net.minecraftforge.fml.ModList";
    
    private final CloudMist_CS plugin;
    private final EnumMap<WeaponType, WeaponStats> weaponStats;
    private final WeaponLoadoutManager loadoutManager;
    private boolean taczEnabled = false;
    private final ConcurrentHashMap<String, String> weaponMapping;
    
    public WeaponManager(CloudMist_CS plugin) {
        this.plugin = plugin;
        this.weaponStats = new EnumMap<>(WeaponType.class);
        this.loadoutManager = new WeaponLoadoutManager();
        this.weaponMapping = new ConcurrentHashMap<>();
        
        loadWeaponMapping();
        initializeTaczSupport();
    }
    
    private void loadWeaponMapping() {
        ConfigurationSection mappingSection = plugin.getConfig()
            .getConfigurationSection("mods.tacz.weapons.mapping");
        if (mappingSection != null) {
            for (String key : mappingSection.getKeys(false)) {
                weaponMapping.put(key, mappingSection.getString(key));
            }
        }
    }
    
    private void initializeTaczSupport() {
        if (plugin.getConfig().getBoolean("mods.tacz.enabled", true)) {
            try {
                // 检查是否在 Forge 环境下
                Class<?> forgeClass = Class.forName(TACZ_REGISTRY_CLASS);
                if (forgeClass != null) {
                    Object modList = forgeClass.getMethod("get").invoke(null);
                    boolean isModLoaded = (boolean) forgeClass.getMethod("isLoaded", String.class)
                        .invoke(modList, TACZ_MOD_ID);
                    
                    if (isModLoaded) {
                        taczEnabled = true;
                        LOGGER.info("§a成功加载 TACZ 模组持!");
                    } else {
                        LOGGER.warning("§c未找到 TACZ 模组，将使用默认武器系统");
                        taczEnabled = false;
                    }
                }
            } catch (Exception e) {
                LOGGER.warning("§c服务器未运行在 Forge 环境下，无法加载 TACZ 模组");
                LOGGER.warning("§c请确保服务器使用 Forge 或 Mohist/Magma 等混合核心");
                taczEnabled = false;
                if (plugin.getConfig().getBoolean("debug")) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public boolean buyWeapon(Player player, WeaponType weapon, boolean isCT, CSGame game) {
        // 检查玩家金钱是否足够
        int price = weapon.getPrice();
        if (!game.canAfford(player, price)) {
            player.sendMessage("§c你没有足够的金钱购买此武器! 需要: $" + price);
            return false;
        }
        
        if (isCT && !weapon.isCtCanBuy()) {
            player.sendMessage("§c该武器只能由T方购买!");
            return false;
        } else if (!isCT && weapon.isCtCanBuy()) {
            player.sendMessage("§c该武器只能由CT方购买!");
            return false;
        }
        
        if (game.purchaseWeapon(player, weapon)) {
            giveWeapon(player, weapon.getId());
            weaponStats.computeIfAbsent(weapon, k -> new WeaponStats())
                       .addPurchase();
            player.sendMessage("§a成功购买 " + weapon.getDisplayName() + " §a花费: $" + price);
            return true;
        }
        return false;
    }
    
    public void giveDefaultLoadout(Player player, Team team) {
        player.getInventory().clear();
        
        if (team == Team.TERRORIST) {
            // T队默认装备
            ItemStack bomb = new ItemStack(Material.TNT, 1);
            ItemMeta meta = bomb.getItemMeta();
            meta.setDisplayName("§c§lC4炸弹");
            bomb.setItemMeta(meta);
            // 确保每回合都给予C4
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                player.getInventory().setItem(8, bomb);
            }, 1L);
        }
        
        // 给予默认武器
        giveDefaultWeapons(player, team);
    }
    
    public void giveDefaultWeapons(Player player, Team team) {
        // 根据队伍给予默认武器
        if (team == Team.TERRORIST) {
            giveWeapon(player, "GLOCK17");
        } else if (team == Team.COUNTER_TERRORIST) {
            giveWeapon(player, "GLOCK17");
        }
    }
    
    public void giveWeapon(Player player, String weaponId) {
        if (weaponId == null || weaponId.isEmpty()) {
            plugin.getLogger().warning("尝试给予空武器ID给玩家: " + player.getName());
            return;
        }
        
        if (taczEnabled) {
            try {
                String command = String.format("give %s %s", 
                    player.getName(),
                    weaponId
                );
                
                plugin.getLogger().fine("执行武器给予命令: " + command);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                
                plugin.getLogger().fine("已给予玩家 " + player.getName() + " 武器: " + weaponId);
            } catch (Exception e) {
                player.sendMessage("§c获取武器失败，请联系管理员");
                if (plugin.getConfig().getBoolean("debug")) {
                    plugin.getLogger().warning("给予武器失败: " + weaponId);
                    e.printStackTrace();
                }
            }
        } else {
            // 如果TACZ未启用，给予普通物品
            ItemStack weapon = new ItemStack(Material.DIAMOND_SWORD);
            ItemMeta meta = weapon.getItemMeta();
            meta.setDisplayName("§f" + weaponId);
            List<String> lore = new ArrayList<>();
            lore.add("§7模拟武器 - TACZ模组未启用");
            meta.setLore(lore);
            weapon.setItemMeta(meta);
            player.getInventory().setItemInMainHand(weapon);
            player.sendMessage("§e由于TACZ模组未启用，使用模拟武器替代");
        }
    }
    
    private WeaponType getCurrentWeapon(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item != null && item.getType() != Material.AIR) {
            return WeaponType.getById(item.getType().name().toLowerCase());
        }
        return null;
    }
    
    public void saveLoadout(Player player) {
        WeaponType currentWeapon = getCurrentWeapon(player);
        if (currentWeapon != null) {
            loadoutManager.saveLoadout(player, "default", currentWeapon);
        }
    }
    
    public void loadLoadout(Player player) {
        WeaponType weapon = loadoutManager.getLoadout(player, "default");
        if (weapon != null) {
            giveWeapon(player, weapon.getId());
        }
    }
    
    public void dropWeapon(Player player) {}
    
    public void reloadConfig() {
        // 清除现有的映射
        weaponMapping.clear();
        taczEnabled = false;
        
        // 重新加载配置
        loadWeaponMapping();
        initializeTaczSupport();
        
        if (plugin.getConfig().getBoolean("debug")) {
            LOGGER.info("武器管理器配置已重新加载");
            LOGGER.info("TACZ模组支持: " + (taczEnabled ? "已启用" : "未启用"));
            LOGGER.info("已加载武器映射: " + weaponMapping.toString());
        }
    }
} 