package WLYD.cloudMist_CS.weapon;

public enum WeaponType {
    GLOCK17("modern_kinetic_gun{GunId:\"tacz:glock17\",GunFireMode:\"SEMI\"}", "格洛克17", 200, true),
    AK47("modern_kinetic_gun{GunId:\"tacz:ak47\",GunFireMode:\"SEMI\"}", "AK-47", 2700, false),
    M4A1("modern_kinetic_gun{GunId:\"tacz:m4a1\",GunFireMode:\"SEMI\"}", "M4A1", 3100, true),
    DEAGLE("modern_kinetic_gun{GunId:\"tacz:desert_eagle\",GunFireMode:\"SEMI\"}", "沙漠之鹰", 700, true),
    AWP("modern_kinetic_gun{GunId:\"tacz:awp\",GunFireMode:\"SEMI\"}", "AWP狙击枪", 4750, true);

    private final String id;
    private final String displayName;
    private final int price;
    private final boolean ctCanBuy;

    WeaponType(String id, String displayName, int price, boolean ctCanBuy) {
        this.id = id;
        this.displayName = displayName;
        this.price = price;
        this.ctCanBuy = ctCanBuy;
    }

    public String getId() {
        return id;
    }

    public int getPrice() {
        return price;
    }

    public boolean isCtCanBuy() {
        return ctCanBuy;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static WeaponType getById(String id) {
        for (WeaponType type : values()) {
            if (type.getId().equalsIgnoreCase(id)) {
                return type;
            }
        }
        return null;
    }
}