package WLYD.cloudMist_CS.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import WLYD.cloudMist_CS.CloudMist_CS;
import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

public class ConfigManager {
    private final CloudMist_CS plugin;
    private final Logger logger;
    private final ConcurrentHashMap<String, FileConfiguration> configCache;
    private FileConfiguration gameConfig;
    private FileConfiguration economyConfig;
    private FileConfiguration weaponsConfig;
    private FileConfiguration modsConfig;
    
    public ConfigManager(CloudMist_CS plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        this.configCache = new ConcurrentHashMap<>();
        loadConfigs();
    }
    
    private void loadConfigs() {
        // 确保配置目录存在
        File configDir = new File(plugin.getDataFolder(), "configs");
        if (!configDir.exists() && !configDir.mkdirs()) {
            throw new RuntimeException("无法创建配置目录: " + configDir.getPath());
        }
        
        // 加载主配置
        plugin.saveDefaultConfig();
        
        try {
            // 加载其他配置
            gameConfig = loadConfig("configs/game.yml");
            economyConfig = loadConfig("configs/economy.yml");
            weaponsConfig = loadConfig("configs/weapons.yml");
            modsConfig = loadConfig("configs/mods.yml");
            
            // 缓存配置
            configCache.put("game", gameConfig);
            configCache.put("economy", economyConfig);
            configCache.put("weapons", weaponsConfig);
            configCache.put("mods", modsConfig);
        } catch (Exception e) {
            logger.severe("加载配置文件时发生错误: " + e.getMessage());
            throw new RuntimeException("配置加载失败", e);
        }
    }
    
    private FileConfiguration loadConfig(String path) {
        File file = new File(plugin.getDataFolder(), path);
        if (!file.exists()) {
            try {
                plugin.saveResource(path, false);
            } catch (Exception e) {
                logger.severe("无法保存默认配置文件 " + path + ": " + e.getMessage());
                throw new RuntimeException("配置保存失败", e);
            }
        }
        try {
            return YamlConfiguration.loadConfiguration(file);
        } catch (Exception e) {
            logger.severe("无法加载配置文件 " + path + ": " + e.getMessage());
            throw new RuntimeException("配置加载失败", e);
        }
    }
    
    public void reloadConfigs() {
        synchronized (this) {
            configCache.clear();
            loadConfigs();
        }
    }
    
    public FileConfiguration getConfig(String name) {
        return configCache.get(name);
    }
    
    public FileConfiguration getGameConfig() {
        return getConfig("game");
    }
    
    public FileConfiguration getEconomyConfig() {
        return getConfig("economy");
    }
    
    public FileConfiguration getWeaponsConfig() {
        return getConfig("weapons");
    }
    
    public FileConfiguration getModsConfig() {
        return getConfig("mods");
    }
} 