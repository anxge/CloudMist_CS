package WLYD.cloudMist_CS.game;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import WLYD.cloudMist_CS.CloudMist_CS;
import WLYD.cloudMist_CS.weapon.WeaponManager;
import WLYD.cloudMist_CS.economy.Economy;
import WLYD.cloudMist_CS.weapon.WeaponType;
import WLYD.cloudMist_CS.scoreboard.ScoreboardManager;
import java.util.ArrayList;
import WLYD.cloudMist_CS.stats.PlayerStats;
import WLYD.cloudMist_CS.event.GameEventListener;
import WLYD.cloudMist_CS.event.RoundEndEvent;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;
import WLYD.cloudMist_CS.utils.PerformanceMonitor;
import java.util.stream.Collectors;
import org.bukkit.World;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Firework;
import org.bukkit.FireworkEffect;
import org.bukkit.Color;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.scheduler.BukkitRunnable;

public class CSGame {
    private final String name;
    private final Location lobbyLocation;
    private Location tSpawn;    // T队出生点
    private Location ctSpawn;   // CT队出生点
    private final Set<Player> players;
    private GameState state;
    private final Map<Player, Team> playerTeams;
    private final Map<Team, Set<Player>> teamPlayers;
    private static final int MAX_PLAYERS_PER_TEAM = 5;
    private static final int MIN_PLAYERS_PER_TEAM = 1;
    private static final int COUNTDOWN_SECONDS = 10;
    private int taskId = -1;
    private final WeaponManager weaponManager;
    private final Economy economy;
    private final ScoreboardManager scoreboardManager;
    private int roundNumber = 0;
    private final Map<Team, Integer> teamScores = new HashMap<>();
    private final Map<Player, Integer> playerKills = new HashMap<>();
    private final Map<Player, Integer> playerDeaths = new HashMap<>();
    private int roundTimeLeft;
    private int roundTimerTaskId = -1;
    private final GameSettings settings;
    private List<GameEventListener> eventListeners;  // 事件监听器
    private GameTimer gameTimer;  // 游戏计时器封装
    private final Queue<Runnable> updateQueue = new ConcurrentLinkedQueue<>();
    private final CloudMist_CS plugin;
    private boolean bombPlanted = false;
    private Location bombLocation = null;
    private Player bombPlanter = null;
    private int bombTaskId = -1;
    private final LoadingCache<UUID, PlayerStats> statsCache = CacheBuilder.newBuilder()
        .expireAfterAccess(10, TimeUnit.MINUTES)
        .build(new CacheLoader<UUID, PlayerStats>() {
            @Override
            public PlayerStats load(@Nonnull UUID playerId) {
                return new PlayerStats();
            }
        });
    private final BombSiteManager bombSiteManager;
    private final List<Location> buyZones = new ArrayList<>();
    private TNTPrimed bombEntity;  // TNT实体
    private ArmorStand hologram;   // 全息倒计时显示
    
    public CSGame(String name, Location lobby, WeaponManager weaponManager) {
        this.plugin = CloudMist_CS.getInstance();
        this.name = name;
        this.lobbyLocation = lobby;
        this.weaponManager = weaponManager;
        this.players = new HashSet<>();
        this.playerTeams = new HashMap<>();
        this.teamPlayers = new HashMap<>();
        this.economy = new Economy();
        this.scoreboardManager = new ScoreboardManager(this);
        this.settings = new GameSettings();
        this.eventListeners = new ArrayList<>();
        this.gameTimer = new GameTimer(this);
        this.bombSiteManager = new BombSiteManager();
        this.state = GameState.WAITING;
        
        // 初化队伍玩家集合
        teamPlayers.put(Team.TERRORIST, new HashSet<>());
        teamPlayers.put(Team.COUNTER_TERRORIST, new HashSet<>());
        teamPlayers.put(Team.SPECTATOR, new HashSet<>());
        
        // 初始化队伍分数
        teamScores.put(Team.TERRORIST, 0);
        teamScores.put(Team.COUNTER_TERRORIST, 0);
        teamScores.put(Team.SPECTATOR, 0);
        
        startUpdateTask();
    }
    
    public boolean joinTeam(Player player, Team team) {
        if (team != Team.SPECTATOR && teamPlayers.get(team).size() >= MAX_PLAYERS_PER_TEAM) {
            player.sendMessage("§c该队伍已满!");
            return false;
        }
        
        if (plugin.getConfig().getBoolean("debug")) {
            plugin.getLogger().info(String.format("玩家 %s 尝试加入 %s 队伍", player.getName(), team.name()));
        }
        
        // 如果玩家已经在某个队伍中，先离开原队伍
        Team oldTeam = playerTeams.get(player);
        if (oldTeam != null) {
            teamPlayers.get(oldTeam).remove(player);
        }
        
        // 加入新队伍
        playerTeams.put(player, team);
        teamPlayers.get(team).add(player);
        
        if (plugin.getConfig().getBoolean("debug")) {
            plugin.getLogger().info(String.format("玩家 %s 当前队伍: %s", 
                player.getName(), getPlayerTeam(player)));
            plugin.getLogger().info(String.format("队伍人数 - T: %d, CT: %d", 
                teamPlayers.get(Team.TERRORIST).size(),
                teamPlayers.get(Team.COUNTER_TERRORIST).size()));
        }
        
        // 发送消息
        String message = String.format("§6%s §f加入了 %s §f队伍", 
            player.getName(), team.getDisplayName());
        broadcastMessage(message);
        
        updateAllScoreboards();
        return true;
    }
    
    public void addPlayer(Player player) {
        players.add(player);
        player.teleport(lobbyLocation);
        // 新加入默认加入观察者
        joinTeam(player, Team.SPECTATOR);
        // 初始化玩家经济
        economy.initializePlayer(player);
        player.sendMessage("§a你已加入游戏 " + name);
        updateScoreboard(player);
    }
    
    public void removePlayer(Player player) {
        players.remove(player);
        Team team = playerTeams.remove(player);
        if (team != null) {
            teamPlayers.get(team).remove(player);
        }
        // 清除经济数据
        economy.removePlayer(player);
        // 清除计分板
        scoreboardManager.removeScoreboard(player);
        player.sendMessage("§c你已离开游戏 " + name);
        updateAllScoreboards();
    }
    
    public String getName() {
        return name;
    }
    
    public Set<Player> getPlayers() {
        return new HashSet<>(players);
    }
    
    public GameState getState() {
        return state;
    }
    
    public Team getPlayerTeam(Player player) {
        return playerTeams.get(player);
    }
    
    public Set<Player> getTeamPlayers(Team team) {
        return new HashSet<>(teamPlayers.get(team));
    }
    
    private void broadcastMessage(String message) {
        for (Player player : players) {
            player.sendMessage(message);
        }
    }
    
    public boolean startGame() {
        if (plugin.getConfig().getBoolean("debug")) {
            plugin.getLogger().info("===== 游戏启动检查 =====");
            plugin.getLogger().info("游戏状: " + state);
            plugin.getLogger().info("T队玩家列表: " + teamPlayers.get(Team.TERRORIST));
            plugin.getLogger().info("CT队玩家列表: " + teamPlayers.get(Team.COUNTER_TERRORIST));
            plugin.getLogger().info("T队人数: " + teamPlayers.get(Team.TERRORIST).size());
            plugin.getLogger().info("CT队人数: " + teamPlayers.get(Team.COUNTER_TERRORIST).size());
            plugin.getLogger().info("最小玩家数求: " + MIN_PLAYERS_PER_TEAM);
        }
        
        // 查游戏状态
        if (state != GameState.WAITING) {
            if (plugin.getConfig().getBoolean("debug")) {
                plugin.getLogger().info("游状态检查失败: " + state);
            }
            broadcastMessage("§c游戏已经在进行在准备!");
            return false;
        }
        
        // 检查出生点是否已设置
        if (tSpawn == null || ctSpawn == null) {
            broadcastMessage("§c无法开始游戏，出生点未设置完全!");
            return false;
        }
        
        // 检查每个队伍的玩家数量
        int tCount = teamPlayers.get(Team.TERRORIST).size();
        int ctCount = teamPlayers.get(Team.COUNTER_TERRORIST).size();
        
        if (tCount < MIN_PLAYERS_PER_TEAM || ctCount < MIN_PLAYERS_PER_TEAM) {
            broadcastMessage("§c无法开始游，每队至少需要 1 名玩家!");
            broadcastMessage(String.format("§c当前人数 - T队: %d, CT队: %d", tCount, ctCount));
            return false;
        }
        
        // 记录试信息
        if (plugin.getConfig().getBoolean("debug")) {
            plugin.getLogger().info(String.format("尝试开始游戏 - T队: %d, CT队: %d人", tCount, ctCount));
        }
        
        // 置游状态为准备中
        state = GameState.STARTING;
        startCountdown();
        return true;
    }
    
    private void startCountdown() {
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(CloudMist_CS.getInstance(), new Runnable() {
            private int countdown = COUNTDOWN_SECONDS;
            
            @Override
            public void run() {
                if (countdown > 0) {
                    broadcastMessage(String.format("§6游戏将在 §e%d §6秒后开始!", countdown));
                    countdown--;
                } else {
                    Bukkit.getScheduler().cancelTask(taskId);
                    beginRound();
                }
            }
        }, 0L, 20L); // 20 ticks = 1 second
    }
    
    private void beginRound() {
        setState(GameState.FREEZE_TIME);
        roundNumber++;
        
        // 重置回合状态
        bombPlanted = false;
        bombLocation = null;
        bombPlanter = null;
        
        // 为所有玩家重置装备
        for (Player player : players) {
            Team team = getPlayerTeam(player);
            if (team != Team.SPECTATOR) {
                weaponManager.giveDefaultLoadout(player, team);
            }
        }
        
        // 传送玩家到出生点
        for (Player player : teamPlayers.get(Team.TERRORIST)) {
            player.teleport(tSpawn);
        }
        for (Player player : teamPlayers.get(Team.COUNTER_TERRORIST)) {
            player.teleport(ctSpawn);
        }
        
        // 分发回合开始装备
        distributeRoundStartEquipment();
        
        // 开始冻结时间
        broadcastMessage("§6=== 准备时间 ===");
        gameTimer.start(settings.getFreezeTime());
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (state == GameState.FREEZE_TIME) {
                setState(GameState.BUY_TIME);
                // 保持玩家冻结状态
                for (Player player : players) {
                    freezePlayer(player);
                }
                gameTimer.start(settings.getBuyTime());
                broadcastMessage("§a购买时间开始！");
                startBuyTimer();
            }
        }, settings.getFreezeTime() * 20L);
    }
    
    private void freezePlayer(Player player) {
        player.setWalkSpeed(0);
        player.setFlySpeed(0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 128, false, false));
        player.setGameMode(GameMode.ADVENTURE); // 防止破坏块
    }
    
    private void unfreezePlayer(Player player) {
        player.setWalkSpeed(0.2f); // 默认行走速度
        player.setFlySpeed(0.1f);  // 默认飞行速
        player.removePotionEffect(PotionEffectType.JUMP);
        player.setGameMode(GameMode.SURVIVAL);
    }
    
    private void distributeRoundStartEquipment() {
        for (Player player : teamPlayers.get(Team.TERRORIST)) {
            weaponManager.giveDefaultWeapons(player, Team.TERRORIST);
        }
        for (Player player : teamPlayers.get(Team.COUNTER_TERRORIST)) {
            weaponManager.giveDefaultWeapons(player, Team.COUNTER_TERRORIST);
        }
    }
    
    private void startBuyTimer() {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (state == GameState.BUY_TIME) {
                setState(GameState.IN_PROGRESS);
                // 解除所有玩家的冻结状态
                for (Player player : players) {
                    unfreezePlayer(player);
                }
                broadcastMessage("§c购买时间结束！");
                gameTimer.start(settings.getRoundTime());
                startRoundTimer();
            }
        }, settings.getBuyTime() * 20L);
    }
    
    private void startRoundTimer() {
        gameTimer.start(settings.getRoundTime());
    }
    
    public void endRound(Team winningTeam) {
        // 取消计时器
        if (roundTimerTaskId != -1) {
            Bukkit.getScheduler().cancelTask(roundTimerTaskId);
            roundTimerTaskId = -1;
        }
        
        // 触发回合结事件
        RoundEndEvent event = new RoundEndEvent(this, winningTeam);
        for (GameEventListener listener : eventListeners) {
            listener.onRoundEnd(event);
        }
        
        // 添加队伍得分
        addTeamScore(winningTeam);
        
        // 广播果
        broadcastMessage("§6=== 回合结束 ===");
        broadcastMessage(String.format("§6胜利伍: %s", winningTeam.getDisplayName()));
        
        // 检查游戏是否结束
        if (shouldEndGame()) {
            endGame(winningTeam);
            return;
        }
        
        // 延迟开始下一回合
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (state != GameState.ENDING) {
                beginRound();
            }
        }, 5 * 20L);
    }
    
    private boolean shouldEndGame() {
        int tScore = teamScores.get(Team.TERRORIST);
        int ctScore = teamScores.get(Team.COUNTER_TERRORIST);
        return tScore >= settings.getWinScore() || ctScore >= settings.getWinScore();
    }
    
    private void endGame(Team winningTeam) {
        state = GameState.ENDING;
        broadcastMessage("§6=== 游戏结束 ===");
        broadcastMessage(String.format("§6胜利队伍: %s", winningTeam.getDisplayName()));
        resetGame();
    }
    
    private void resetGame() {
        roundNumber = 0;
        teamScores.put(Team.TERRORIST, 0);
        teamScores.put(Team.COUNTER_TERRORIST, 0);
        playerKills.clear();
        playerDeaths.clear();
        
        // 重置所有玩家
        for (Player player : players) {
            player.setGameMode(GameMode.SURVIVAL);
            player.getInventory().clear();
            player.teleport(lobbyLocation);
            economy.initializePlayer(player); // 重置金钱
        }
        
        state = GameState.WAITING;
        updateAllScoreboards();
    }
    
    public void stopGame() {
        if (taskId != -1) {
            Bukkit.getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        
        state = GameState.WAITING;
        broadcastMessage("§c游戏结束!");
        
        // 重置所有玩
        for (Player player : players) {
            player.setGameMode(GameMode.SURVIVAL);
            player.getInventory().clear();
            player.teleport(lobbyLocation);
        }
    }
    
    // 加设置出生点的方法
    public void setSpawnPoint(Team team, Location location) {
        if (team == Team.TERRORIST) {
            this.tSpawn = location;
        } else if (team == Team.COUNTER_TERRORIST) {
            this.ctSpawn = location;
        }
    }
    
    public boolean canBuyWeapon(Player player, WeaponType weapon) {
        return economy.getMoney(player) >= weapon.getPrice();
    }
    
    public boolean purchaseWeapon(Player player, WeaponType weapon) {
        // 检查是否在购买区
        if (!isInBuyZone(player)) {
            player.sendMessage("§c必须在购买区内才能购买武器！");
            return false;
        }
        
        int price = weapon.getPrice();
        return economy.removeMoney(player, price);
    }
    
    private boolean isInBuyZone(Player player) {
        Location loc = player.getLocation();
        return buyZones.stream().anyMatch(zone -> zone.distance(loc) <= 10) ||
            (state == GameState.FREEZE_TIME || state == GameState.BUY_TIME) && 
            (loc.distance(tSpawn) <= 10 || loc.distance(ctSpawn) <= 10);
    }
    
    public void updateScoreboard(Player player) {
        scoreboardManager.updateScoreboard(player, this);
    }
    
    public void updateAllScoreboards() {
        for (Player player : players) {
            updateScoreboard(player);
        }
    }
    
    public Economy getEconomy() {
        return economy;
    }
    
    public void addKill(Player killer, Player victim) {
        PlayerStats killerStats = getPlayerStats(killer);
        PlayerStats victimStats = getPlayerStats(victim);
        
        killerStats.addKill();
        victimStats.addDeath();
        
        // 检合利条件
        checkRoundWinCondition();
        
        // 更新记分板
        updateAllScoreboards();
    }
    
    private void checkRoundWinCondition() {
        if (state != GameState.IN_PROGRESS) {
            return;
        }
        
        // 查C4状态
        if (bombPlanted) {
            // 如果C4已安装，只有拆除或爆炸才能结束回合
            return;
        }
        
        int aliveT = 0;
        int aliveCT = 0;
        
        // 计算存活人数
        for (Player player : players) {
            if (player.isDead()) continue;
            
            Team team = getPlayerTeam(player);
            if (team == Team.TERRORIST) {
                aliveT++;
            } else if (team == Team.COUNTER_TERRORIST) {
                aliveCT++;
            }
        }
        
        // 判定胜利条件
        if (aliveT == 0 && !bombPlanted) {
            // 有T死亡且安装C4，CT胜利
            endRound(Team.COUNTER_TERRORIST);
            broadcastMessage("§6反恐精英 胜利！");
        } else if (aliveCT == 0) {
            // 所有CT死亡，T胜利
            endRound(Team.TERRORIST);
            broadcastMessage("§6恐怖分子 胜利！");
        }
    }
    
    public void addTeamScore(Team team) {
        teamScores.put(team, teamScores.get(team) + 1);
        
        // 予回合奖励
        for (Player player : teamPlayers.get(team)) {
            economy.addRoundReward(player, true);
        }
        Team losingTeam = (team == Team.TERRORIST) ? Team.COUNTER_TERRORIST : Team.TERRORIST;
        for (Player player : teamPlayers.get(losingTeam)) {
            economy.addRoundReward(player, false);
        }
        
        updateAllScoreboards();
    }
    
    public int getRoundNumber() {
        return roundNumber;
    }
    
    public int getTeamScore(Team team) {
        return teamScores.getOrDefault(team, 0);
    }
    
    public int getKills(Player player) {
        return playerKills.getOrDefault(player, 0);
    }
    
    public int getDeaths(Player player) {
        return playerDeaths.getOrDefault(player, 0);
    }
    
    public int getRoundTimeLeft() {
        return roundTimeLeft;
    }
    
    public GameSettings getSettings() {
        return settings;
    }
    
    public void saveSettings() {
        settings.saveToConfig(name, CloudMist_CS.getInstance().getConfig());
        CloudMist_CS.getInstance().saveConfig();
    }
    
    public void loadSettings() {
        settings.loadFromConfig(name, CloudMist_CS.getInstance().getConfigManager().getGameConfig());
    }
    
    public void pauseGame() {}  // 游戏暂停
    public void resumeGame() {} // 游戏继续
    public void restartRound() {} // 重启当前回合
    
    public void queueUpdate(Runnable update) {
        if (update != null) {
            synchronized(updateQueue) {
                updateQueue.offer(update);
            }
        }
    }
    
    private void processUpdates() {
        boolean hasUpdates = false;
        List<Runnable> updates = new ArrayList<>();
        
        synchronized(updateQueue) {
            while (!updateQueue.isEmpty() && updates.size() < 100) {
                updates.add(updateQueue.poll());
                hasUpdates = true;
            }
        }
        
        if (hasUpdates) {
            PerformanceMonitor.startTiming("game_updates");
        }
        
        for (Runnable task : updates) {
            try {
                task.run();
            } catch (Exception e) {
                plugin.getLogger().severe("游戏更新处理错误: " + e.getMessage());
                if (plugin.getConfig().getBoolean("debug")) {
                    e.printStackTrace();
                }
            }
        }
        
        if (hasUpdates) {
            PerformanceMonitor.endTiming("game_updates");
        }
    }
    
    private void startUpdateTask() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(CloudMist_CS.getInstance(), () -> {
            processUpdates();
        }, 1L, 1L);
    }
    
    // 修改GameTimer类中的broadcastTime方法
    public void broadcastTime(int seconds) {
        if ((seconds % 30 == 0 || seconds <= 10) && seconds > 0) {
            String stateMsg = "";
            switch (state) {
                case FREEZE_TIME:
                    stateMsg = "准备时间";
                    break;
                case BUY_TIME:
                    stateMsg = "购买时间";
                    break;
                case IN_PROGRESS:
                    stateMsg = "回合时间";
                    break;
                case STARTING:
                    stateMsg = "开始倒计时";
                    break;
                case WAITING:
                case ENDING:
                case WARMUP:
                default:
                    stateMsg = "等时间";
                    break;
            }
            broadcastMessage(String.format("§e%s剩余: %d 秒", stateMsg, seconds));
        }
    }
    
    // 添加玩家统计相关的方法
    public PlayerStats getPlayerStats(Player player) {
        return statsCache.getUnchecked(player.getUniqueId());
    }
    
    public void addEventListener(GameEventListener listener) {
        eventListeners.add(listener);
    }
    
    public void removeEventListener(GameEventListener listener) {
        eventListeners.remove(listener);
    }
    
    public void handleTimeUp() {
        if (state == GameState.IN_PROGRESS) {
            // 时间到，CT胜
            Team winningTeam = Team.COUNTER_TERRORIST;
            endRound(winningTeam);
        } else if (state == GameState.WARMUP) {
            startGame();
        }
    }
    
    public Location getLobbyLocation() {
        return lobbyLocation;
    }
    
    public Location getTSpawn() {
        return tSpawn;
    }
    
    public Location getCTSpawn() {
        return ctSpawn;
    }
    
    public List<Location> getBombSites() {
        return bombSiteManager.getBombSites().stream()
            .map(BombSite::getLocation)
            .collect(Collectors.toList());
    }
    
    public List<Location> getBuyZones() {
        return new ArrayList<>(buyZones);
    }
    
    public void addBombSite(Location location) {
        bombSiteManager.addBombSite(location);
    }
    
    public void addBuyZone(Location location) {
        buyZones.add(location);
    }
    
    public void onBombPlanted(Player planter, Location location) {
        if (!bombSiteManager.isInBombSite(location)) {
            planter.sendMessage("§c你必须在弹安装点内安装C4！");
            return;
        }
        
        bombPlanted = true;
        bombLocation = location;
        bombPlanter = planter;
        
        // 在安装位置生成点燃的TNT
        World world = location.getWorld();
        if (world != null) {
            // 生成TNT实体并设置其属性
            Location tntLoc = location.clone().add(0.5, 0, 0.5);
            bombEntity = world.spawn(tntLoc, TNTPrimed.class);
            bombEntity.setFuseTicks(settings.getBombTimer() * 20);
            bombEntity.setGravity(false);
            bombEntity.setYield(0);
            
            // 创建全息倒计时
            hologram = world.spawn(tntLoc.clone().add(0, 1.5, 0), ArmorStand.class);
            hologram.setVisible(false);
            hologram.setGravity(false);
            hologram.setCanPickupItems(false);
            hologram.setCustomNameVisible(true);
            hologram.setMarker(true);
            
            // 启动倒计时更新任务
            int timeLeft = settings.getBombTimer();
            new BukkitRunnable() {
                int countdown = timeLeft;
                
                @Override
                public void run() {
                    if (!bombPlanted || countdown <= 0) {
                        if (hologram != null && !hologram.isDead()) {
                            hologram.remove();
                        }
                        this.cancel();
                        return;
                    }
                    
                    hologram.setCustomName("§c" + countdown + "秒");
                    countdown--;
                }
            }.runTaskTimer(plugin, 0L, 20L);
        }
        
        // 启动C4爆炸计时
        bombTaskId = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (bombPlanted) {
                createExplosionEffect(bombLocation);
                endRound(Team.TERRORIST);
                broadcastMessage("§c§l轰！C4爆炸了！");
            }
        }, settings.getBombTimer() * 20L).getTaskId();
        
        broadcastMessage("§c§l恐怖分子已安装C4！");
    }
    
    public Location getBombLocation() {
        return bombLocation;
    }
    
    public Player getBombPlanter() {
        return bombPlanter;
    }
    
    public void onBombDefused(Player defuser) {
        if (!bombPlanted) return;
        
        bombPlanted = false;
        if (bombTaskId != -1) {
            Bukkit.getScheduler().cancelTask(bombTaskId);
            bombTaskId = -1;
        }
        
        // 移除TNT实体和全息图
        if (bombEntity != null && !bombEntity.isDead()) {
            bombEntity.remove();
            bombEntity = null;
        }
        
        if (hologram != null && !hologram.isDead()) {
            hologram.remove();
            hologram = null;
        }
        
        // 清除炸弹位置
        bombLocation = null;
        
        // 给予拆弹奖励
        int defuseReward = plugin.getConfigManager().getGameConfig().getInt("rewards.bomb_defuse", 300);
        economy.addMoney(defuser, defuseReward);
        
        endRound(Team.COUNTER_TERRORIST);
        broadcastMessage("§a" + defuser.getName() + " 成功拆除了C4！");
    }
    
    private void setState(GameState newState) {
        this.state = newState;
        updateAllScoreboards();
    }
    
    public void registerBombSite(String name, Location location, double radius) {
        bombSiteManager.registerBombSite(name, location, radius);
    }
    
    public boolean canAfford(Player player, int amount) {
        return economy.getMoney(player) >= amount;
    }
    
    public void onPlayerQuit(Player player) {
        players.remove(player);
        Team team = getPlayerTeam(player);
        if (team != null) {
            teamPlayers.get(team).remove(player);
        }
        
        // 检查游戏是否应该结束
        checkGameEnd();
    }
    
    public void checkGameEnd() {
        // 检查是否有胜利条件
        if (teamScores.get(Team.TERRORIST) >= settings.getWinScore()) {
            endRound(Team.TERRORIST);
            broadcastMessage("§6恐怖分子胜利！");
        } else if (teamScores.get(Team.COUNTER_TERRORIST) >= settings.getWinScore()) {
            endRound(Team.COUNTER_TERRORIST);
            broadcastMessage("§6反恐精英胜利！");
        } else if (players.size() < settings.getMinPlayers()) {
            // 如果玩家数量少于最小要求，结束戏
            broadcastMessage("§c游戏结束，玩家数量不足！");
            endRound(null); // null 表示没有胜利队伍
        }
    }
    
    // 添加爆炸特效方法
    private void createExplosionEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        // 生成烟花
        Firework firework = world.spawn(location, Firework.class);
        FireworkMeta meta = firework.getFireworkMeta();
        
        // 设置烟花效果
        FireworkEffect effect = FireworkEffect.builder()
            .with(FireworkEffect.Type.BALL_LARGE)
            .withColor(Color.RED, Color.ORANGE)
            .withFade(Color.YELLOW)
            .trail(true)
            .flicker(true)
            .build();
            
        meta.addEffect(effect);
        meta.setPower(2);
        firework.setFireworkMeta(meta);
        
        // 添加粒子效果
        world.spawnParticle(Particle.EXPLOSION_HUGE, location, 1);
        world.spawnParticle(Particle.FLAME, location, 50, 1, 1, 1, 0.1);
        world.spawnParticle(Particle.SMOKE_LARGE, location, 100, 2, 2, 2, 0.1);
        
        // 播放爆炸音效
        world.playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.0f);
    }
    
    public boolean isBombPlanted() {
        return bombPlanted; // 返回炸弹是否已安��
    }
    
    public int getPlayerCount() {
        return players.size(); // 返回当前玩家数量
    }
} 