package WLYD.cloudMist_CS.game;

import WLYD.cloudMist_CS.weapon.WeaponManager;
import WLYD.cloudMist_CS.CloudMist_CS;
import WLYD.cloudMist_CS.data.MapData;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class GameManager {
    private final Map<String, CSGame> games;
    private final Map<Player, CSGame> playerGame;
    private final WeaponManager weaponManager;
    private final CloudMist_CS plugin;
    
    public GameManager(WeaponManager weaponManager) {
        this.plugin = CloudMist_CS.getInstance();
        this.games = new HashMap<>();
        this.playerGame = new HashMap<>();
        this.weaponManager = weaponManager;
    }
    
    public boolean createGame(String name, Location lobby) {
        if (games.containsKey(name)) {
            return false;
        }
        games.put(name, new CSGame(name, lobby, weaponManager));
        return true;
    }
    
    public boolean joinGame(Player player, String gameName) {
        CSGame game = games.get(gameName);
        if (game == null || playerGame.containsKey(player)) {
            return false;
        }
        
        game.addPlayer(player);
        playerGame.put(player, game);
        return true;
    }
    
    public boolean leaveGame(Player player) {
        CSGame game = playerGame.get(player);
        if (game == null) {
            return false;
        }
        
        game.removePlayer(player);
        playerGame.remove(player);
        return true;
    }
    
    public CSGame getPlayerGame(Player player) {
        return playerGame.get(player);
    }
    
    public CSGame getGameByLocation(Location location) {
        for (CSGame game : games.values()) {
            Location lobby = game.getLobbyLocation();
            if (lobby.getWorld().equals(location.getWorld()) && 
                lobby.distance(location) <= 100) {
                return game;
            }
        }
        return null;
    }
    
    public void saveAllGames() {
        for (CSGame game : games.values()) {
            plugin.getDataManager().saveMapData(game.getName(), new MapData(game));
        }
    }
    
    public Map<String, CSGame> getGames() {
        return games;
    }
} 