package WLYD.cloudMist_CS.game;

import org.bukkit.Location;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

public class BombSiteManager {
    private final Set<BombSite> bombSites = new HashSet<>();
    
    public void addBombSite(Location location) {
        bombSites.add(new BombSite("site" + (bombSites.size() + 1), location, 5.0));
    }
    
    public void registerBombSite(String name, Location location, double radius) {
        bombSites.add(new BombSite(name, location, radius));
    }
    
    public boolean isInBombSite(Location location) {
        return bombSites.stream().anyMatch(site -> site.isInside(location));
    }
    
    public BombSite getNearestBombSite(Location location) {
        return bombSites.stream()
            .min((a, b) -> Double.compare(
                a.getCenter().distance(location),
                b.getCenter().distance(location)))
            .orElse(null);
    }
    
    public Set<BombSite> getBombSites() {
        return new HashSet<>(bombSites);
    }
    
    public void removeBombSite(String name) {
        bombSites.removeIf(site -> site.getName().equals(name));
    }
    
    public BombSite getBombSite(String name) {
        return bombSites.stream()
            .filter(site -> site.getName().equals(name))
            .findFirst()
            .orElse(null);
    }
    
    public List<Location> getBombSiteLocations() {
        List<Location> locations = new ArrayList<>();
        for (BombSite site : bombSites) {
            locations.add(site.getLocation());
        }
        return locations;
    }
} 