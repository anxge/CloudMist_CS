package WLYD.cloudMist_CS.game;

import org.bukkit.Location;

public class BombSite {
    private final String name;
    private final Location location;
    private final double radius;
    
    public BombSite(String name, Location location, double radius) {
        this.name = name;
        if (location == null) {
            throw new IllegalArgumentException("炸弹点位置不能为空");
        }
        this.location = location.clone();
        this.radius = radius;
    }
    
    public String getName() { return name; }
    public Location getLocation() { return location.clone(); }
    public Location getCenter() { return location; }
    
    public boolean isInside(Location loc) {
        if (loc == null || loc.getWorld() != location.getWorld()) {
            return false;
        }
        return location.distance(loc) <= radius;
    }
} 