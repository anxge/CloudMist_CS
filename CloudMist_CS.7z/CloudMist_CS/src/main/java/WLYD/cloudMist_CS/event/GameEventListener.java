package WLYD.cloudMist_CS.event;

// 这些事件类都在同一个包中,不需要显式导入

public interface GameEventListener {
    void onRoundStart(RoundStartEvent event);
    void onRoundEnd(RoundEndEvent event);
    void onPlayerKill(PlayerKillEvent event);
    void onPlayerDeath(PlayerDeathEvent event);
    void onBombPlant(BombPlantEvent event);
    void onBombDefuse(BombDefuseEvent event);
    void onPlayerJoinTeam(PlayerJoinTeamEvent event);
    void onGameStateChange(GameStateChangeEvent event);
} 