package WLYD.cloudMist_CS.event;

import WLYD.cloudMist_CS.game.CSGame;

public abstract class GameEvent {
    protected final CSGame game;
    
    public GameEvent(CSGame game) {
        this.game = game;
    }
    
    public CSGame getGame() {
        return game;
    }
} 