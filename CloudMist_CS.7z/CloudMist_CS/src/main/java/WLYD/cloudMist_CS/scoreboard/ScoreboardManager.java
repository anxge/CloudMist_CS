package WLYD.cloudMist_CS.scoreboard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import WLYD.cloudMist_CS.game.CSGame;
import java.util.HashMap;
import java.util.Map;
import WLYD.cloudMist_CS.game.Team;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.scoreboard.Criteria;

public class ScoreboardManager {
    private final Map<Player, Scoreboard> scoreboards = new HashMap<>();

    public ScoreboardManager(CSGame game) {
    }
    
    private void createScoreboard(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        scoreboards.put(player, board);
    }
    
    public void updateScoreboard(Player player, CSGame game) {
        Scoreboard board = scoreboards.get(player);
        if (board == null) {
            createScoreboard(player);
            board = scoreboards.get(player);
        }

        // 设置玩家的计分板
        player.setScoreboard(board);

        Objective objective = board.getObjective("game");
        if (objective != null) {
            objective.unregister();
        }
        
        objective = board.registerNewObjective("game", Criteria.DUMMY, "§6CS:GO");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        
        Team playerTeam = game.getPlayerTeam(player);
        boolean isT = playerTeam == Team.TERRORIST;
        
        List<String> lines = new ArrayList<>();
        lines.add("§7================");
        lines.add(String.format("§f回合: §e%d/%d", 
            game.getRoundNumber(), 
            game.getSettings().getMaxRounds()));
        
        // 显示双方比分，突出显示自己的队伍
        int tScore = game.getTeamScore(Team.TERRORIST);
        int ctScore = game.getTeamScore(Team.COUNTER_TERRORIST);
        if (isT) {
            lines.add(String.format("§c恐怖分子: §e%d", tScore));
            lines.add(String.format("§7反恐精英: §7%d", ctScore));
        } else {
            lines.add(String.format("§7恐怖分子: §7%d", tScore));
            lines.add(String.format("§b反恐精英: §e%d", ctScore));
        }
        
        lines.add("§7----------------");
        lines.add(String.format("§f金钱: §e$%d", 
            game.getEconomy().getMoney(player)));
        lines.add(String.format("§f击杀: §a%d", 
            game.getKills(player)));
        lines.add(String.format("§f死亡: §c%d", 
            game.getDeaths(player)));
        
        // 显示当前阶段
        String stateDisplay = "";
        switch (game.getState()) {
            case FREEZE_TIME:
                stateDisplay = "§b准备时间";
                break;
            case BUY_TIME:
                stateDisplay = "§a购买时间";
                break;
            case IN_PROGRESS:
                stateDisplay = "§6进行中";
                break;
            default:
                stateDisplay = "§7等待中";
        }
        lines.add(String.format("§f状态: %s", stateDisplay));
        lines.add("§7================");

        // 设置计分板行
        int score = lines.size();
        for (String line : lines) {
            objective.getScore(line).setScore(score--);
        }
    }
    
    public void removeScoreboard(Player player) {
        scoreboards.remove(player);
        player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
    }
} 