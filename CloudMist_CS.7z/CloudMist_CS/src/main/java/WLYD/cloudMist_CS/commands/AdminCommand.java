package WLYD.cloudMist_CS.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import WLYD.cloudMist_CS.CloudMist_CS;
import WLYD.cloudMist_CS.game.CSGame;
import WLYD.cloudMist_CS.game.Team;
import java.util.Map;

public class AdminCommand implements CommandExecutor {
    private final CloudMist_CS plugin;
    
    public AdminCommand(CloudMist_CS plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("cloudmist.admin")) {
            sender.sendMessage("§c你没有权限使用此命令！");
            return true;
        }
        
        if (args.length == 0) {
            sendHelpMessage(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "create":
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /csadmin create <游戏名称>");
                    return true;
                }
                handleCreate(sender, args[1]);
                break;
                
            case "delete":
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /csadmin delete <游戏名称>");
                    return true;
                }
                handleDelete(sender, args[1]);
                break;
                
            case "list":
                handleList(sender);
                break;
                
            case "info":
                if (args.length < 2) {
                    sender.sendMessage("§c用法: /csadmin info <游戏名称>");
                    return true;
                }
                handleInfo(sender, args[1]);
                break;
                
            case "setspawn":
                if (args.length < 3) {
                    sender.sendMessage("§c用法: /csadmin setspawn <游戏名称> <t/ct>");
                    return true;
                }
                handleSetSpawn(sender, args[1], args[2]);
                break;
                
            case "setbombsite":
                if (args.length < 3) {
                    sender.sendMessage("§c用法: /csadmin setbombsite <游戏名称> <A/B>");
                    return true;
                }
                handleSetBombSite(sender, args[1], args[2]);
                break;
                
            default:
                sendHelpMessage(sender);
                break;
        }
        
        return true;
    }
    
    private void sendHelpMessage(CommandSender sender) {
        sender.sendMessage("§6========= CS游戏管理命令 =========");
        sender.sendMessage("§e/csadmin create <名称> §7- 创建新游戏");
        sender.sendMessage("§e/csadmin delete <名称> §7- 删除游戏");
        sender.sendMessage("§e/csadmin list §7- 列出所有游戏");
        sender.sendMessage("§e/csadmin info <名称> §7- 查看游戏详情");
        sender.sendMessage("§e/csadmin setspawn <名称> <t/ct> §7- 设置出生点");
        sender.sendMessage("§e/csadmin setbombsite <名称> <A/B> §7- 设置炸弹安装点");
        sender.sendMessage("§6================================");
    }
    
    private void handleCreate(CommandSender sender, String gameName) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行！");
            return;
        }
        
        Player player = (Player) sender;
        Location location = player.getLocation();
        
        if (plugin.getGameManager().createGame(gameName, location)) {
            sender.sendMessage("§a成功创建游戏 " + gameName);
        } else {
            sender.sendMessage("§c创建游戏失败，该名称可能已被使用");
        }
    }
    
    private void handleDelete(CommandSender sender, String gameName) {
        Map<String, CSGame> games = plugin.getGameManager().getGames();
        if (games.containsKey(gameName)) {
            games.remove(gameName);
            sender.sendMessage("§a成功删除游戏 " + gameName);
        } else {
            sender.sendMessage("§c找不到名为 " + gameName + " 的游戏");
        }
    }
    
    private void handleList(CommandSender sender) {
        Map<String, CSGame> games = plugin.getGameManager().getGames();
        if (games.isEmpty()) {
            sender.sendMessage("§e目前没有任何游戏");
            return;
        }
        
        sender.sendMessage("§6========= 游戏列表 =========");
        for (CSGame game : games.values()) {
            sender.sendMessage("§e- " + game.getName() + " §7(玩家数: " + 
                game.getPlayerCount() + ", 状态: " + game.getState() + ")");
        }
        sender.sendMessage("§6==========================");
    }
    
    private void handleInfo(CommandSender sender, String gameName) {
        CSGame game = plugin.getGameManager().getGames().get(gameName);
        if (game == null) {
            sender.sendMessage("§c找不到名为 " + gameName + " 的游戏");
            return;
        }
        
        sender.sendMessage("§6========= 游戏信息 " + gameName + " =========");
        sender.sendMessage("§e状态: §f" + game.getState());
        sender.sendMessage("§e玩家数: §f" + game.getPlayerCount());
        sender.sendMessage("§eT队分数: §f" + game.getTeamScore(Team.TERRORIST));
        sender.sendMessage("§eCT队分数: §f" + game.getTeamScore(Team.COUNTER_TERRORIST));
        sender.sendMessage("§e当前回合: §f" + game.getRoundNumber());
        sender.sendMessage("§6===================================");
    }
    
    private void handleSetSpawn(CommandSender sender, String gameName, String team) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行！");
            return;
        }
        
        CSGame game = plugin.getGameManager().getGames().get(gameName);
        if (game == null) {
            sender.sendMessage("§c找不到名为 " + gameName + " 的游戏");
            return;
        }
        
        Player player = (Player) sender;
        Location location = player.getLocation();
        
        if (team.equalsIgnoreCase("t")) {
            game.setSpawnPoint(Team.TERRORIST, location);
            sender.sendMessage("§a已设置 " + gameName + " 的T队出生点");
        } else if (team.equalsIgnoreCase("ct")) {
            game.setSpawnPoint(Team.COUNTER_TERRORIST, location);
            sender.sendMessage("§a已设置 " + gameName + " 的CT队出生点");
        } else {
            sender.sendMessage("§c无效的队伍，请使用 t 或 ct");
        }
    }
    
    private void handleSetBombSite(CommandSender sender, String gameName, String site) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c此命令只能由玩家执行！");
            return;
        }
        
        CSGame game = plugin.getGameManager().getGames().get(gameName);
        if (game == null) {
            sender.sendMessage("§c找不到名为 " + gameName + " 的游戏");
            return;
        }
        
        Player player = (Player) sender;
        Location location = player.getLocation();
        
        game.registerBombSite(site.toUpperCase(), location, 3.0);
        sender.sendMessage("§a已设置 " + gameName + " 的炸弹安装点 " + site.toUpperCase());
    }
}