package WLYD.cloudMist_CS;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Bukkit;
import WLYD.cloudMist_CS.game.GameManager;
import WLYD.cloudMist_CS.weapon.WeaponManager;
import WLYD.cloudMist_CS.data.DataManager;
import WLYD.cloudMist_CS.data.PlayerData;
import WLYD.cloudMist_CS.config.ConfigManager;
import WLYD.cloudMist_CS.listener.BombListener;
import WLYD.cloudMist_CS.listener.FreezeTimeListener;
import WLYD.cloudMist_CS.log.LogManager;
import WLYD.cloudMist_CS.commands.AdminCommand;

public final class CloudMist_CS extends JavaPlugin {
    private static CloudMist_CS instance;
    private ConfigManager configManager;
    private GameManager gameManager;
    private WeaponManager weaponManager;
    private DataManager dataManager;
    private LogManager logManager;
    private BombListener bombListener;
    private final String logo = 
        "██╗    ██╗██╗\n" +
        "██║    ██║██║\n" +
        "██║ █╗ ██║██║\n" +
        "██║███╗██║██║  \n" +
        "╚███╔███╔╝███████╗\n" +
        " ╚══╝╚══╝ ╚══════╝\n";
    
    @Override
    public void onEnable() {
        // 打印 LOGO
        getLogger().info(logo);
        
        // 保存插件实例
        instance = this;
        
        // 初始化日志管理器
        logManager = new LogManager(this);
        
        // 初始化配置管理器
        configManager = new ConfigManager(this);
        
        // 初始化数据管理器
        dataManager = new DataManager(this);
        
        // 初始化武器管理器
        weaponManager = new WeaponManager(this);
        
        // 始化游戏管理器
        gameManager = new GameManager(weaponManager);
        
        // 初始 BombListener
        bombListener = new BombListener(this);
        
        // 注册命令
        if (getCommand("cmcs") == null) {
            getLogger().warning("命令 'cmcs' 注册失败! 请尝试使用其他别名命令: /cs, /csgo");
        } else {
            getCommand("cmcs").setExecutor(new CSCommandExecutor(this));
        }
        
        // 注册事件监听器
        Bukkit.getPluginManager().registerEvents(new GameListener(this), this);
        Bukkit.getPluginManager().registerEvents(new BombListener(this), this);
        getServer().getPluginManager().registerEvents(new FreezeTimeListener(this), this);
        
        // 注册管理命令
        getCommand("csadmin").setExecutor(new AdminCommand(this));
        
        // 输出启动信息
        getLogger().info("CloudMist CS 插件已启动! 可用命令: /cmcs, /cs, /csgo");
        
        // 模拟所有插件加载完成后再次打印LOGO
        Bukkit.getScheduler().runTaskLater(this, () -> getLogger().info(logo), 20L * 10); // 延迟10秒打印
    }

    @Override
    public void onDisable() {
        // 打印 LOGO
        getLogger().info(logo);
        
        // 关闭日志系统
        if (logManager != null) {
            logManager.close();
        }
        
        // 保存所有游戏数据
        gameManager.saveAllGames();
        
        // 保存所有玩家数据
        for (org.bukkit.entity.Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = dataManager.loadPlayerData(player.getUniqueId());
            dataManager.savePlayerData(player.getUniqueId(), data);
        }
        
        saveConfig();
        getLogger().info("CloudMist CS 插件已关闭!");
    }
    
    // 获取插件实例的静态方法
    public static CloudMist_CS getInstance() {
        return instance;
    }
    
    // 获取置件
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public GameManager getGameManager() {
        return gameManager;
    }
    
    public WeaponManager getWeaponManager() {
        return weaponManager;
    }
    
    public DataManager getDataManager() {
        return dataManager;
    }
    
    public LogManager getLogManager() {
        return logManager;
    }
    
    public BombListener getBombListener() {
        return bombListener;
    }
}
