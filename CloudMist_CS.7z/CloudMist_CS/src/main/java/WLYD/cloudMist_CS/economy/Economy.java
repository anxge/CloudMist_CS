package WLYD.cloudMist_CS.economy;

import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.List;
import WLYD.cloudMist_CS.CloudMist_CS;
import WLYD.cloudMist_CS.game.CSGame;

public class Economy {
    public enum RewardType {
        BOMB_PLANT,
        BOMB_DEFUSE,
        HEADSHOT
    }
    
    private final Map<UUID, Integer> playerMoney;
    private Map<UUID, List<Transaction>> transactionHistory;
    private EconomyConfig config;
    private final Map<UUID, Integer> consecutiveLosses = new HashMap<>();
    
    public Economy() {
        this.playerMoney = new HashMap<>();
        this.config = new EconomyConfig();
        this.transactionHistory = new HashMap<>();
    }
    
    public void initializePlayer(Player player) {
        int startMoney = CloudMist_CS.getInstance().getConfigManager().getEconomyConfig().getInt("starting_money", 800);
        setMoney(player, startMoney);
    }
    
    public void removePlayer(Player player) {
        playerMoney.remove(player.getUniqueId());
    }
    
    public int getMoney(Player player) {
        return playerMoney.getOrDefault(player.getUniqueId(), 0);
    }
    
    public void setMoney(Player player, int amount) {
        playerMoney.put(player.getUniqueId(), Math.max(0, amount));
        updateScoreboard(player);
    }
    
    public boolean addMoney(Player player, int amount) {
        int current = getMoney(player);
        setMoney(player, current + amount);
        return true;
    }
    
    public boolean removeMoney(Player player, int amount) {
        int current = getMoney(player);
        if (current < amount) {
            return false;
        }
        setMoney(player, current - amount);
        return true;
    }
    
    public void addKillReward(Player player) {
        addMoney(player, config.getKillReward());
        player.sendMessage(String.format("§a+$%d §7(击杀奖励)", config.getKillReward()));
    }
    
    public void addRoundReward(Player player, boolean isWinner) {
        UUID id = player.getUniqueId();
        int lossCount = consecutiveLosses.getOrDefault(id, 0);
        
        if (isWinner) {
            addMoney(player, config.getWinReward());
            consecutiveLosses.put(id, 0);
        } else {
            int lossBonus = 1400 + (lossCount * 500);
            lossBonus = Math.min(lossBonus, 3400);
            addMoney(player, lossBonus);
            consecutiveLosses.put(id, lossCount + 1);
        }
    }
    
    private void updateScoreboard(Player player) {
        CSGame game = CloudMist_CS.getInstance().getGameManager().getPlayerGame(player);
        if (game != null) {
            game.updateScoreboard(player);
        }
    }
    
    public boolean canAfford(Player player, int amount) {
        return getMoney(player) >= amount;
    }
    
    public void refundLastPurchase(Player player) {
        // 实现退款逻辑
    }
    
    public List<Transaction> getTransactionHistory(Player player) {
        return transactionHistory.getOrDefault(player.getUniqueId(), List.of());
    }
    
    public void addBonusReward(Player player, RewardType type) {
        switch (type) {
            case BOMB_PLANT:
                addMoney(player, 300);
                break;
            case BOMB_DEFUSE:
                addMoney(player, 400);
                break;
            case HEADSHOT:
                addMoney(player, 100);
                break;
        }
    }
} 