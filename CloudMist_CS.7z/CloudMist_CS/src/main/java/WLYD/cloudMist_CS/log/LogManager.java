package WLYD.cloudMist_CS.log;

import WLYD.cloudMist_CS.CloudMist_CS;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class LogManager {
    private final CloudMist_CS plugin;
    private final Logger logger;
    private FileHandler gameLogHandler;
    private FileHandler debugLogHandler;
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public LogManager(CloudMist_CS plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
        initializeLogSystem();
        cleanOldLogs();
    }
    
    private void initializeLogSystem() {
        try {
            // 创建日志目录
            File logDir = new File(plugin.getDataFolder(), "logs");
            if (!logDir.exists()) {
                logDir.mkdirs();
            }
            
            // 创建游戏日志处理器
            String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            gameLogHandler = new FileHandler(logDir.getPath() + "/game-" + date + ".log", true);
            debugLogHandler = new FileHandler(logDir.getPath() + "/debug-" + date + ".log", true);
            
            // 设置日志格式
            Formatter logFormatter = new Formatter() {
                @Override
                public String format(LogRecord record) {
                    return String.format("[%s] [%s] %s%n",
                        LocalDateTime.now().format(DATE_FORMAT),
                        record.getLevel(),
                        record.getMessage());
                }
            };
            
            gameLogHandler.setFormatter(logFormatter);
            debugLogHandler.setFormatter(logFormatter);
            
            // 添加处理器到logger
            logger.addHandler(gameLogHandler);
            if (plugin.getConfig().getBoolean("debug", false)) {
                logger.addHandler(debugLogHandler);
            }
            
        } catch (IOException e) {
            logger.severe("初始化日志系统失败: " + e.getMessage());
        }
    }
    
    private void cleanOldLogs() {
        try {
            File logDir = new File(plugin.getDataFolder(), "logs");
            if (!logDir.exists()) return;
            
            int keepDays = plugin.getConfig().getInt("log.keep_days", 7);
            LocalDateTime cutoffDate = LocalDateTime.now().minusDays(keepDays);
            
            File[] logFiles = logDir.listFiles();
            if (logFiles != null) {
                for (File file : logFiles) {
                    String fileName = file.getName();
                    // 忽略锁文件
                    if (fileName.endsWith(".lck")) continue;
                    
                    try {
                        // 检查文件名是否符合格式 (game|debug|error)-YYYY-MM-DD.log
                        if (!fileName.matches("(game|debug|error)-\\d{4}-\\d{2}-\\d{2}\\.log")) continue;
                        
                        // 从文件名中提取日期
                        String dateStr = fileName.substring(fileName.indexOf('-') + 1).split("\\.")[0];
                        LocalDateTime fileDate = LocalDateTime.parse(dateStr, 
                            DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                        
                        if (fileDate.isBefore(cutoffDate)) {
                            if (file.delete()) {
                                logger.fine("已删除过期日志文件: " + fileName);
                            }
                        }
                    } catch (Exception e) {
                        // 降低日志级别，因为这不是严重错误
                        logger.fine("跳过不符合格式的日志文件: " + fileName);
                    }
                }
            }
        } catch (Exception e) {
            logger.severe("清理旧日志文件时出错: " + e.getMessage());
        }
    }
    
    public void logGame(String message) {
        logger.info(message);
        writeToFile("game", message);
    }
    
    public void logDebug(String message) {
        if (plugin.getConfig().getBoolean("debug", false)) {
            logger.info("[Debug] " + message);
            writeToFile("debug", message);
        }
    }
    
    public void logError(String message, Throwable error) {
        logger.severe(message);
        writeToFile("error", message + "\n" + getStackTrace(error));
    }
    
    private void writeToFile(String type, String message) {
        try {
            File logDir = new File(plugin.getDataFolder(), "logs");
            String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            File logFile = new File(logDir, type + "-" + date + ".log");
            
            if (!logFile.exists()) {
                logFile.createNewFile();
            }
            
            try (FileWriter fw = new FileWriter(logFile, true);
                 BufferedWriter bw = new BufferedWriter(fw)) {
                bw.write(String.format("[%s] %s%n", 
                    LocalDateTime.now().format(DATE_FORMAT), 
                    message));
            }
        } catch (IOException e) {
            logger.severe("入日志失败: " + e.getMessage());
        }
    }
    
    private String getStackTrace(Throwable error) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        error.printStackTrace(pw);
        return sw.toString();
    }
    
    public void close() {
        if (gameLogHandler != null) {
            gameLogHandler.close();
        }
        if (debugLogHandler != null) {
            debugLogHandler.close();
        }
    }
} 