plugins {
    id("java")
    id("com.github.johnrengelman.shadow") version "7.1.2"
}

group = "WLYD"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    maven("https://hub.spigotmc.org/nexus/content/repositories/snapshots/")
    maven("https://oss.sonatype.org/content/repositories/snapshots")
    maven("https://jitpack.io")
    maven {
        name = "Curse Maven"
        url = uri("https://www.cursemaven.com")
        content {
            includeGroup("curse.maven")
        }
    }
}

dependencies {
    compileOnly("org.spigotmc:spigot-api:1.20.1-R0.1-SNAPSHOT") {
        exclude(module = "bungeecord-chat")
    }
    implementation("com.google.guava:guava:31.1-jre")
    // TACZ 模组依赖
    compileOnly(files("libs/TACZ-1.0.jar")) // 假设TACZ模组jar放在libs目录下
    compileOnly("curse.maven:timeless-and-classics-zero-1028108:5529117-sources-5529578")
}

tasks {
    shadowJar {
        archiveClassifier.set("")
        relocate("com.google.guava", "WLYD.cloudMist_CS.libs.guava")
    }
    
    build {
        dependsOn(shadowJar)
    }
    
    processResources {
        filesMatching("plugin.yml") {
            expand(project.properties)
        }
    }
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
} 